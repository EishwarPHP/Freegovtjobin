<div class="clearfix"></div>
		
	<div class="clearfix"></div>
		<div class="col-md-12 social-icons">
			<a href="https://www.facebook.com/Freegovjobin-100697312691642/" target="_blank"><div class="col-md-2 facebook">
				<i class="fa fa-facebook" aria-hidden="true"></i>
			</div></a>
			<a href="#"><div class="col-md-2 yahoo">
				<i class="fa fa-yahoo" aria-hidden="true"></i>
			</div></a>
			<a href="#"><div class="col-md-2 linkedin">
				<i class="fa fa-linkedin" aria-hidden="true"></i>
			</div></a>
			<a href="#"><div class="col-md-2 google">
				<i class="fa fa-google-plus" aria-hidden="true"></i>
			</div></a>
			<a href="#"><div class="col-md-2 pinterest">
				<i class="fa fa-pinterest-p" aria-hidden="true"></i>
			</div></a>
			<a href="#"><div class="col-md-2 twitter">
				<i class="fa fa-twitter" aria-hidden="true"></i>
			</div></a>
			<a href="#"><div class="col-md-2 dribbble">
				<i class="fa fa-dribbble" aria-hidden="true"></i>
			</div></a>
			<a href="#" ><div class="col-md-2 youtube ">
				<i class="fa fa-youtube" aria-hidden="true"></i>
			</div></a>
			<a href="#"><div class="col-md-2 tumblr">
				<i class="fa fa-tumblr" aria-hidden="true"></i>
			</div></a>
			<div class="clearfix"></div>
		</div>
		<div class="clearfix"></div>
		<div class="footer-agileits-w3layouts">
			<p class="agileinfo"> &copy; 2022 Freegovtjob.in All Rights Reserved | Design by <a href="http://Freegovtjob.in" style="color: #222">Freegovtjob.in</a></p>
		</div>
	</div>
	<!--  player js -->

        <script type="text/javascript" src="https://www.google.com/jsapi"></script>
        <script>
            google.load("jquery", "1.7.1");
            google.load("jqueryui", "1.8.16");
        </script>
        <script src="{{asset('frontend/js/script.js')}}"></script>
<!--  player js -->
        <script src="{{asset('frontend/js/Chart.min.js')}}"></script>
        <script src="{{asset('frontend/js/pretty-doughtnut.js')}}"></script>
        <script src="{{asset('frontend/js/easyResponsiveTabs.js')}}" type="text/javascript"></script>
        <script src="{{asset('frontend/js/skycons.js')}}"></script>
        <script src="{{asset('frontend/js/underscore-min.js')}}" type="text/javascript"></script>
        <script src= "js/moment-2.2.1.js')}}" type="text/javascript"></script>
        <script src="{{asset('frontend/js/clndr.js')}}" type="text/javascript"></script>
        <script src="{{asset('frontend/js/site.js')}}" type="text/javascript"></script>
</body>
</html>