<?php echo $__env->make('frontcommon.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		<div class="clearfix"></div>
		<?php if($message = Session::get('success')): ?>
		
			<div class="alert alert-info alert-block" align="center" id="flashmessage">
			<strong><?php echo e($message); ?></strong>
			</div>
			<?php endif; ?>

			<script>
				setTimeout(function () {
						$("#flashmessage").hide('p');
					}, 2500);
				
			</script>
		
		
		
		<div class="clearfix"></div>
		<div class="col-md-12 left-w3l table-responsive" >
			<div class="sub-topp sub-top">
				<h4><?php echo e($title); ?></h4>
			</div>
			<table class="table table-striped" bordercolor="#eee" style="background: #fff" border="1"> 
				<tbody>
					<tr>
						<td>
							<table border="1" bordercolor="#eee" class="table">
								<?php $__currentLoopData = $notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resnotes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><a href="<?php echo e(url('details')); ?>/<?php echo e($resnotes->id); ?>"><?php echo e($resnotes->title); ?></a></td>	
								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</table>
						</td>
					</tr>
				</tbody>
			</table>
            <?php echo e($notes->links()); ?>

			<div class="clearfix"></div>
		</div>

		<?php echo $__env->make('frontcommon.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Freegovtjobin\resources\views/welcome-category.blade.php ENDPATH**/ ?>