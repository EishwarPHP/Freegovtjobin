<?php echo $__env->make('frontcommon.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		<div class="clearfix"></div>
		<?php if($message = Session::get('success')): ?>
		
			<div class="alert alert-info alert-block" align="center" id="flashmessage">
			<strong><?php echo e($message); ?></strong>
			</div>
			<?php endif; ?>

			<script>
				setTimeout(function () {
						$("#flashmessage").hide('p');
					}, 2500);
				
			</script>
		
		<div class="col-md-6" >
			<?php if($notes->onlylink!=null): ?>
				<a href="<?php echo e($notes->onlylink); ?>" class="btn btn-primary btn-lg"><?php echo e($notes->title); ?></a>
			<?php else: ?>
				<a href="<?php echo e(url('details')); ?>/<?php echo e($notes->id); ?>" class="btn btn-primary btn-lg"><?php echo e($notes->title); ?></a>
			<?php endif; ?>
				
			<div class="clearfix"><br></div>
		</div>
		<div class="col-md-6  text-center" style="margin-top:-10px;">
			<form action="<?php echo e(route('Subscriptions')); ?>" method="post">
				<?php echo csrf_field(); ?>
				<div class="col-md-8  text-center" >
					<label for=""><small>Subscribe to Get all The Latest Updates !</small></label>
				<input type="email" name="emails" class="form-control" placeholder="Enter Email" required>
				</div>
				<div class="col-md-4  text-center" >
					<label for="">&nbsp;</label>
				<input type="submit" name="submit" class="btn btn-warning" value="Subscribe Now">
				</div>
			</form>
			<div class="clearfix"><br></div>
		</div>
		
		<div class="clearfix"></div>
		<div class="col-md-12 left-w3l table-responsive" >
			<div class="sub-topp sub-top">
				<h4>New update</h4>
			</div>
			<table class="table table-striped" bordercolor="#eee" style="background: #fff" border="1"> 
				
				<tbody>
					<tr>
						
						<td>
							<table border="1" bordercolor="#eee" class="table">
								<?php $__currentLoopData = $newupdate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resnotes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
										<?php if($resnotes->onlylink!=null): ?>
											<td><a href="<?php echo e($resnotes->onlylink); ?>" target="_blank"><?php echo e($resnotes->title); ?></a></td>
										<?php else: ?>
											<td><a href="<?php echo e(url('details')); ?>/<?php echo e($resnotes->id); ?>"><?php echo e($resnotes->title); ?></a></td>
										<?php endif; ?>
								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</table>
						</td>
						<td>
							<table border="1" bordercolor="#eee" class="table">
								<?php $__currentLoopData = $newupdate1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resnotes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
										<?php if($resnotes->onlylink!=null): ?>
											<td><a href="<?php echo e($resnotes->onlylink); ?>"  target="_blank"><?php echo e($resnotes->title); ?></a></td>
										<?php else: ?>
											<td><a href="<?php echo e(url('details')); ?>/<?php echo e($resnotes->id); ?>"><?php echo e($resnotes->title); ?></a></td>
										<?php endif; ?>
									
								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</table >
						</td>
						
					</tr>
					<tr>
						<td class="text-center" colspan="2">
							<a href="<?php echo e(url('welcome-category')); ?>/Newupdate" class="hvr-bounce-to-left" style="padding: 10px;color:#fff">View All</a>
						</td>						
					</tr>
				</tbody>
			</table>
			<div class="clearfix"></div>
		</div>
		
		
		<div class="clearfix"></div>
		<?php $__currentLoopData = $box; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<a style="color:#fff;" href="<?php echo e(url('details')); ?>/<?php echo e($res->id); ?>">
					<div class="col-md-4 social-icons" style="margin-bottom: 5px">
						<div class="profile-w3layouts">
							<div class="profile-topp text-center" style="background:<?php echo e('#' . substr(str_shuffle('ABCD01234567'), 0, 6)); ?>;padding:10px;height: 90px;">
									<b><?php echo e($res->title); ?><br><small>Apply Online</small></b>
							</div>
						</div>
					</div>
				</a>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		
		
		<div class="clearfix"></div>
		<div class="col-md-12 left-w3l table-responsive" >
			<div class="sub-topp sub-top">
				<h4>Notifications</h4>
			</div>
			<table class="table table-striped" bordercolor="#eee" style="background: #fff" border="1"> 
				<thead>
					<tr>
						<th>Job Notifications</th>
						<th>Admit Cards</th>
						<th>Results</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						
						<td>
							<table border="1" bordercolor="#eee" class="table">
								<?php $__currentLoopData = $jobnotification; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resnotes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<?php if($resnotes->categoryname=="Job Notification" && $resnotes->setbutton==0): ?>
										<?php if($resnotes->onlylink!=null): ?>
											<td><a href="<?php echo e($resnotes->onlylink); ?>" target="_blank"><?php echo e($resnotes->title); ?></a></td>
										<?php else: ?>
											<td><a href="<?php echo e(url('details')); ?>/<?php echo e($resnotes->id); ?>"><?php echo e($resnotes->title); ?></a></td>
										<?php endif; ?>
									<?php endif; ?>
								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</table>
						</td>
						<td>
							<table border="1" bordercolor="#eee" class="table">
								<?php $__currentLoopData = $admitcard; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resnotes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									
									<?php if($resnotes->categoryname=="Admit Cards" && $resnotes->setbutton==0): ?>
										<?php if($resnotes->onlylink!=null): ?>
											<td><a href="<?php echo e($resnotes->onlylink); ?>"  target="_blank"><?php echo e($resnotes->title); ?></a></td>
										<?php else: ?>
											<td><a href="<?php echo e(url('details')); ?>/<?php echo e($resnotes->id); ?>"><?php echo e($resnotes->title); ?></a></td>
										<?php endif; ?>
									<?php endif; ?>
									
								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</table >
						</td>
						<td>
							<table border="1" bordercolor="#eee" class="table">
								<?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resnotes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<?php if($resnotes->categoryname=="Results" && $resnotes->setbutton==0): ?>
										<?php if($resnotes->onlylink!=null): ?>
											<td><a href="<?php echo e($resnotes->onlylink); ?>" target="_blank"><?php echo e($resnotes->title); ?></a></td>
										<?php else: ?>
											<td><a href="<?php echo e(url('details')); ?>/<?php echo e($resnotes->id); ?>"><?php echo e($resnotes->title); ?></a></td>
										<?php endif; ?>
									<?php endif; ?>
								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</table>
						</td>
					</tr>
					<tr>
						<td class="text-center">
							<a href="<?php echo e(url('welcome-category')); ?>/Job Notification" class="hvr-bounce-to-left" style="padding: 10px;color:#fff">View All</a>
						</td>
						<td class="text-center">
							<a href="<?php echo e(url('welcome-category')); ?>/Admit Cards" class="hvr-bounce-to-left" style="padding: 10px;color:#fff">View All</a>
						</td>
						<td class="text-center">
							<a href="<?php echo e(url('welcome-category')); ?>/Results" class="hvr-bounce-to-left" style="padding: 10px;color:#fff">View All</a>
						</td>
					</tr>
				</tbody>
			</table>
			<div class="clearfix"></div>
		</div>

		<div class="clearfix"></div>
		<div class="col-md-12 left-w3l table-responsive" >
			<div class="sub-topp sub-top">
				<h4>State Job Notifications</h4>
			</div>
			<table class="table table-striped" bordercolor="#eee" style="background: #fff" border="1"> 
				<thead>
					<tr>
						<th>State Job Notifications</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						
						<td>
							<table border="1" bordercolor="#eee" class="table">
								<?php $__currentLoopData = $statejobnotification; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resnotes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<?php if($resnotes->categoryname=="State Job Notifications" && $resnotes->setbutton==0): ?>
										<?php if($resnotes->onlylink!=null): ?>
											<td><a href="<?php echo e($resnotes->onlylink); ?>" target="_blank"><?php echo e($resnotes->title); ?></a></td>
										<?php else: ?>
											<td><a href="<?php echo e(url('details')); ?>/<?php echo e($resnotes->id); ?>"><?php echo e($resnotes->title); ?></a></td>
										<?php endif; ?>
									<?php endif; ?>
								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</table>
						</td>
						
					</tr>
					<tr>
						
						<td class="text-center">
							<a href="<?php echo e(url('welcome-category')); ?>/State Job Notifications" class="hvr-bounce-to-left" style="padding: 10px;color:#fff">View All</a>
						</td>
					</tr>
				</tbody>
			</table>
			<div class="clearfix"></div>
		</div>

		<?php echo $__env->make('frontcommon.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Freegovtjobin\resources\views/welcome.blade.php ENDPATH**/ ?>