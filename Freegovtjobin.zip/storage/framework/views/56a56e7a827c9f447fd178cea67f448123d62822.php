<?php echo $__env->make('backcommon.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- main content start-->
<div id="page-wrapper">
    <div class="main-page">
        <div class="forms">

            <div class="row">
                <h3 class="title1"><small class="text-right">Home / Subscribers</small></h3>
                
                <?php if($message = Session::get('success')): ?>
                    <div class="alert alert-info alert-block" align="center" id="flashmessage">
                        <strong><?php echo e($message); ?></strong>
                    </div>
                <?php endif; ?>

                <script>
                    setTimeout(function() {
                        $("#flashmessage").hide('p');
                    }, 2500);
                </script>
                

                <div class="col-md-12 compose-right widget-shadow">
                    <div class="panel-default">
                        <div class="panel-heading">
                            Subscribers list
                        </div>
                        <div class="inbox-page">
                            <table class="table table-hover">
                                <tr>
                                    <th>#</th>
                                    <th>Emails</th>
                                    <th>Created At</th>
                                </tr>
                                <?php $__currentLoopData = $subscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($res->emails); ?></td>
                                        <td><?php echo e($res->created_at); ?></td>
                                        <td>
                                            
                                            
                                            <a href="<?php echo e(url('deleteSubscribe')); ?>/<?php echo e($res->id); ?>"> <i class="fa fa-trash btn-danger btn btn-xs" title="Delete" onclick="return confirm('Are you Sure you want to delete this record')"></i> </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                            <?php echo e($subscriptions->links()); ?>

                        </div>
                    </div>
                </div>

            </div>

        </div>
    </div>
</div>
<!--footer-->
<div class="footer">
    <p>&copy; 2022 Freegovtjob.in. All Rights Reserved | Design by <a href="https://Freegovtjob.in/" target="_blank">Freegovtjob.in</a></p>
</div>
<!--//footer-->
</div>

<!-- side nav js -->
<script src='<?php echo e(asset('backend/js/SidebarNav.min.js')); ?>' type='text/javascript'></script>
<script>
    $('.sidebar-menu').SidebarNav()
</script>
<!-- //side nav js -->

<!-- Classie -->
<!-- for toggle left push menu script -->
<script src="<?php echo e(asset('backend/js/classie.js')); ?>"></script>
<script>
    var menuLeft = document.getElementById('cbp-spmenu-s1'),
        showLeftPush = document.getElementById('showLeftPush'),
        body = document.body;

    showLeftPush.onclick = function() {
        classie.toggle(this, 'active');
        classie.toggle(body, 'cbp-spmenu-push-toright');
        classie.toggle(menuLeft, 'cbp-spmenu-open');
        disableOther('showLeftPush');
    };

    function disableOther(button) {
        if (button !== 'showLeftPush') {
            classie.toggle(showLeftPush, 'disabled');
        }
    }
</script>
<!-- //Classie -->
<!-- //for toggle left push menu script -->

<!--scrolling js-->
<script src="<?php echo e(asset('backend/js/jquery.nicescroll.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/scripts.js')); ?>"></script>
<!--//scrolling js-->

<!-- Bootstrap Core JavaScript -->
<script src="<?php echo e(asset('backend/js/bootstrap.js')); ?>"></script>
<script src="//cdn.ckeditor.com/4.14.0/standard/ckeditor.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
        $('.ckeditor').ckeditor();
    });
</script>
</body>

</html>

<?php /**PATH D:\xampp\htdocs\Freegovtjobin\resources\views/subscribers.blade.php ENDPATH**/ ?>