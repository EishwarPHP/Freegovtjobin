<?php echo $__env->make('frontcommon.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			
		
		<div class="clearfix"></div>
		<div class="col-md-12 left-w3l" >
			<div class="sub-topp sub-top">
				<h4><?php echo e($notes->title); ?></h4>
			</div>
			
			<div class="col-md-12">
				<?php echo $notes->details ?>
			</div>
			
			<div class="clearfix"></div>
		</div>
		
		
		
		
		<?php echo $__env->make('frontcommon.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Freegovtjobin\resources\views/details.blade.php ENDPATH**/ ?>